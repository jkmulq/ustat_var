.. _reference:

References
==============

.. autosummary::
   :toctree: _autosummary
   :template: custom-module-template.rst
   :recursive:

   ustat_var.varcovar
   ustat_var.ustat_samp_covar
   ustat_var.sampc
   ustat_var.makec
   ustat_var.lamb_sum
   ustat_var.generate_test_data.generate_unique_nan_arrays
   ustat_var.generate_test_data.generate_data
   
