﻿ustat\_var.generate\_test\_data.generate\_data
==============================================

.. currentmodule:: ustat_var.generate_test_data

.. autofunction:: generate_data