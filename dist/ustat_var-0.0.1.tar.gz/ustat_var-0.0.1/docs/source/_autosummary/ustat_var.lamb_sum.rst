﻿ustat\_var.lamb\_sum
====================

.. currentmodule:: ustat_var

.. autofunction:: lamb_sum