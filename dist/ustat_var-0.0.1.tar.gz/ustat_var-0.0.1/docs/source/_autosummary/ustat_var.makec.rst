﻿ustat\_var.makec
================

.. currentmodule:: ustat_var

.. autofunction:: makec