﻿ustat\_var.sampc
================

.. currentmodule:: ustat_var

.. autofunction:: sampc