﻿ustat\_var.ustat\_samp\_covar
=============================

.. currentmodule:: ustat_var

.. autofunction:: ustat_samp_covar