﻿ustat\_var.varcovar
===================

.. currentmodule:: ustat_var

.. autofunction:: varcovar