﻿ustat\_var.generate\_test\_data.generate\_unique\_nan\_arrays
=============================================================

.. currentmodule:: ustat_var.generate_test_data

.. autofunction:: generate_unique_nan_arrays